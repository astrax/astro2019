Eclipse Calculation Scripts
===========================
Some very simple Python scripts to demonstrate it is possible to predict the occurences of eclipse without using the Saros cycle. This is intended for the victims of the flat-Earth dogma, or anyone susceptible to it.